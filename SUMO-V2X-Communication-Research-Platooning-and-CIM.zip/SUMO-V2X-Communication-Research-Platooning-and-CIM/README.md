# SUMO V2X Communication Research (Platooning and CIM)
This project was initially started in 2018 while performing research into [V2X communication](https://en.wikipedia.org/wiki/Vehicle-to-everything) 
coupled with [Autonomous Vehicles](https://en.wikipedia.org/wiki/Self-driving_car) as a part of my dissertation for a degree at the University of Bath.

The project focuses on creating platoons and controlling them using an intersection through [Centralised Intersection Management](https://spectrum.ieee.org/cars-that-think/transportation/self-driving/the-scary-efficiency-of-autonomous-intersections). 
This has been implemented using a combination of SUMO and TraCI (Python).

SUMO is a urban traffic simulator and more information can be found about it [ here ](https://sumo.dlr.de/wiki/Simulation_of_Urban_MObility_-_Wiki)

TraCI is a way of manually viewing information about a SUMO simulation and changing how it behaves while it is running using python (more information [here](https://sumo.dlr.de/wiki/TraCI))

Feel free to build/learn off this and if you have any questions, let me know.

## Getting Started
To start using the project it is relatively simple

1. Install [Python](https://www.python.org/), make sure you tick the box to add python to your system path during installation
2. Install [SUMO](https://sumo.dlr.de/wiki/Installing), make sure you tick the box to add SUMO to your system path during installation
3. Clone this repository into a local area.
4. Run the scenario_runner.py file either by double clicking it or using the command prompt (ex. python scenario_runner.py)
5. It will then give you the options of the scenarios you can run, input your choice and the simulation will start automatically (You can also pass directly from the cmd if you want to bypass the clunky python input code)
6. Explore the code base! I've tried to make it quite well documented within the code and I'd recommend reading in this order: scenario manager ----> simulation manager ---> vehicle ---> platoon ---> intersection controller

Any Python compatible IDE can be used to edit the project, I used Visual Studio but there are plenty others!
More information about the different scenarios and how they work are below.

## Folder Structure
 - Maps: this contains all the maps used in each scenarios, each map has a traffic light version for platooning scenarios and a non-traffic light version for the CIM scenarios. This also contains route information determining how may vehicles spawn in each scenario.
 - output: this is where any outputs from running the simulation will be saved, it only contains a file which determines which data is generated within this repository.
 - src: this is where the Python code which deals with platoons, CIM, vehicles and the simulation resides. This code is run to determine how vehicles in each scenario behave. It also contains the configurations for each different scenario and the main code to execute them.

## Scenarios
 - Scenario 1: the control - nothing added just normal SUMO running
 - Scenario 2: platooning with normal Traffic Light Systems
 - Scenario 3: platooning with CIM
 - Scenario 4: platooning with CIM where platoons zip rather than go one by one.

## Purpose of python files

 - intersectionController: all functions for controlling vehicles and platoons while they approach a traffic light system (used during CIM only)

 - platoon: contains information and functions concerning an individual platoon within the simulation. This contains 
 information such as all cars in the platoon, who the leader is, current speed, length etc. It also acts as a basis for all the functions needed by 
 other aspects of the simulation to change a platoon’s behaviour, this could be setting a target speed, merging with another platoon or disbanding it 
 altogether. Each platoon class also maintains the speed of the platoon ensuring that all vehicles are adhering to the speed set by the platoon leader 
 who follows the normal SUMO vehicle following model and acceleration models.

 - simlib: contains library functions created for this project

 - simulationManager: with every loop this class creates platoon and vehicle objects, 
 places vehicles joining the simulation into any eligible platoons, keeps track of all platoons and vehicles in the simulation and 
 deactivates any vehicles that leave it. It also calls the update functions of every platoon so that they can update their statuses and speed. 

 - vehicle: contains getters and setters for a traci vehicle

 - scenario_manager: contains the configuration data for each different scenario. It uses this to run whichever scenario is requested by the user

 - scenario_runner: acts as a nice entry point for the user, handles getting the right input and then executing the scenario manager properly
